package question2;


import tp4.question1.*;
import tp4.question2.*;
import tp4.question3.*;

import java.io.*;

/**
 * D�crivez votre classe JAVASerialiseDeserialise ici.
 * 
 * @author (votre nom) 
 * @version (un num�ro de version ou une date)
 */
public class JAVASerialiseDeserialise
{
      public static void serialjava(IProgr p, String nomDuFichier){
	   /* a completer */
    }

      public static IProgr deserialjava(String nomDuFichier){
          
       /* a completer */
       return null;
    }    
}

package tp4.question1;

public class Addition extends Binaire{

	public Addition(Expression op1, Expression op2){
	  super(op1,op2);
	 }
	 
  public <T> T accepter(VisiteurExpression<T> v){
    return v.visite(this);
  }

}
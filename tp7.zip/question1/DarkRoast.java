package question1;
/**
 * extrait de http://www.oreilly.com/catalog/hfdesignpat/
 */
public class DarkRoast extends Beverage {
	public DarkRoast() {
		description = "Dark Roast Coffee";
	}
 
	public double cost() {
		return .99;
	}
}

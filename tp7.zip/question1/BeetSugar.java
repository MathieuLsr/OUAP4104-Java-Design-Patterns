package question1;

/**
 * extrait de http://www.oreilly.com/catalog/hfdesignpat/
 */
public class BeetSugar /* a completer */{


/* a completer */

}
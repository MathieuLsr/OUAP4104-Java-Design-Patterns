package question1;

/**
 * extrait de http://www.oreilly.com/catalog/hfdesignpat/
 */
public class Chocolate /* a completer */ {
  
/* a completer */
  
/* a completer */

}

